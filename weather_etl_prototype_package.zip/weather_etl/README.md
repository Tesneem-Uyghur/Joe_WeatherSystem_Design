Minimal package to build unified_data.csv

Run:

pip install -r requirements.txt
python main.py

This will save data/unified_data.csv

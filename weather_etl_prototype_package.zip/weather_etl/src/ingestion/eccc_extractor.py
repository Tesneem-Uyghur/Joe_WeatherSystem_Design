"""ECCC Extractor - Reads and processes CSV data"""

import pandas as pd
import config

class ECCCExtractor:
    def readCSV(self):
        print("📂 Reading ECCC CSV file...")
        try:
            df = pd.read_csv(config.CSV_PATH)
            print(f"✓ Successfully read {len(df)} records from CSV")
            return df
        except Exception as e:
            print(f"✗ Error reading CSV: {e}")
            return pd.DataFrame()

    def filterAugustData(self, df):
        print("🗓️  Filtering for August data...")
        df['date'] = pd.to_datetime(df['date'])
        years = df['date'].dt.year.unique()
        if len(years) == 0:
            print("⚠️  No dates found in CSV")
            return pd.DataFrame()
        recent_year = int(max(years))
        august_df = df[(df['date'].dt.year == recent_year) & (df['date'].dt.month == 8)]
        print(f"✓ Filtered to {len(august_df)} August records for year {recent_year}")
        return august_df

    def selectRequiredColumns(self, df):
        print("📋 Selecting and mapping required columns...")
        column_mapping = {
            'Date/Time': 'date',
            'Max Temp (°C)': 'temp_max',
            'Min Temp (°C)': 'temp_min',
            'Total Precip (mm)': 'precipitation'
        }
        selected_df = df[list(column_mapping.keys())].copy()
        selected_df = selected_df.rename(columns=column_mapping)
        selected_df['temp_max'] = pd.to_numeric(selected_df['temp_max'], errors='coerce')
        selected_df['temp_min'] = pd.to_numeric(selected_df['temp_min'], errors='coerce')
        selected_df['precipitation'] = pd.to_numeric(selected_df['precipitation'], errors='coerce')
        selected_df['precipitation'] = selected_df['precipitation'].fillna(0.0)
        selected_df['source'] = 'ECCC'
        selected_df['data_type'] = 'historical'
        print(f"✓ Selected columns: {list(selected_df.columns)}")
        return selected_df

    def extract(self):
        df = self.readCSV()
        if df.empty:
            return df
        df = self.selectRequiredColumns(df)
        df = self.filterAugustData(df)
        return df

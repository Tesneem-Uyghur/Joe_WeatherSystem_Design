"""API Extractor - minimal version"""

import requests
import pandas as pd
import config

class APIExtractor:
    def __init__(self, params_override=None):
        self.url = getattr(config, 'API_URL', 'https://api.open-meteo.com/v1/forecast')
        self.params = dict(getattr(config, 'API_PARAMS', {}))
        if params_override:
            self.params.update(params_override)

    def fetchAPI(self):
        print("🌐 Fetching data from Open-Meteo API...")
        try:
            response = requests.get(self.url, params=self.params, timeout=10)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"✗ API request failed: {e}")
            return None

    def parseJSON(self, json_data):
        if not json_data:
            return pd.DataFrame()
        if 'daily' in json_data:
            daily = json_data['daily']
            df = pd.DataFrame({
                'date': pd.to_datetime(daily['time']),
                'temp_max': daily.get('temperature_2m_max', []),
                'temp_min': daily.get('temperature_2m_min', []),
                'precipitation': daily.get('precipitation_sum', [])
            })
            return df
        if 'hourly' in json_data:
            hourly = json_data['hourly']
            h_df = pd.DataFrame({'date': pd.to_datetime(hourly['time'])})
            if 'temperature_2m' in hourly:
                h_df['temp_value'] = hourly.get('temperature_2m', [])
            if 'precipitation' in hourly:
                h_df['precipitation'] = hourly.get('precipitation', [])
            h_df['source'] = 'Open-Meteo'
            h_df['data_type'] = 'forecast'
            return h_df
        return pd.DataFrame()

    def extract(self):
        json_data = self.fetchAPI()
        if not json_data:
            return pd.DataFrame()
        df = self.parseJSON(json_data)
        if df.empty:
            return df
        df['source'] = 'Open-Meteo'
        df['data_type'] = 'forecast'
        return df

"""Minimal data validator"""

import pandas as pd
import config

class DataValidator:
    def validateData(self, eccc_df, api_df):
        print("\n🔍 VALIDATING DATA...")
        report = {'eccc_records': len(eccc_df), 'api_records': len(api_df)}
        # Basic checks
        if eccc_df is None: eccc_df = pd.DataFrame()
        if api_df is None: api_df = pd.DataFrame()
        # Ensure date columns exist
        return eccc_df, api_df, report

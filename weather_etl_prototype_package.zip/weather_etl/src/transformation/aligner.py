"""Minimal aligner"""

import pandas as pd

class DataAligner:
    def align(self, df):
        if df.empty:
            return df
        df['date'] = pd.to_datetime(df['date'])
        df['date'] = df['date'].dt.floor('h')
        return df

"""Minimal normalizer"""

class DataNormalizer:
    def normalize(self, df):
        return df

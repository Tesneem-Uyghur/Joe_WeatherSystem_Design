"""Minimal cleaner"""

class DataCleaner:
    def clean(self, df):
        return df

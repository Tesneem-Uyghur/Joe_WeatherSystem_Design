"""Minimal builder to merge datasets"""

import pandas as pd

class UnifiedDataBuilder:
    def mergeDatasets(self, eccc_df, api_df):
        if eccc_df is None: eccc_df = pd.DataFrame()
        if api_df is None: api_df = pd.DataFrame()
        if eccc_df.empty and api_df.empty:
            return pd.DataFrame()
        if eccc_df.empty:
            return api_df
        if api_df.empty:
            return eccc_df
        merged = pd.concat([eccc_df, api_df], ignore_index=True)
        merged = merged.sort_values('date').reset_index(drop=True)
        return merged

    def createFlatTable(self, df):
        flat = df[['date','temp_max','temp_min','precipitation','source','data_type']].copy()
        flat['date'] = pd.to_datetime(flat['date']).dt.tz_localize(None)
        return flat

    def build(self, eccc_df, api_df):
        merged = self.mergeDatasets(eccc_df, api_df)
        flat = self.createFlatTable(merged)
        return flat

"""
Weather ETL Pipeline - Main Entry Point
This package builds the unified table and saves it to CSV.
"""

import sys
sys.path.append('.')

from src.ingestion.eccc_extractor import ECCCExtractor
from src.ingestion.api_extractor import APIExtractor
from src.ingestion.validator import DataValidator
from src.transformation.cleaner import DataCleaner
from src.transformation.aligner import DataAligner
from src.transformation.normalizer import DataNormalizer
from src.transformation.builder import UnifiedDataBuilder


def print_header(title):
    print("\n" + "=" * 60)
    print(f"  {title}")
    print("=" * 60)


def run_etl_pipeline():
    print_header("STEP 1: DATA INGESTION")

    eccc_extractor = ECCCExtractor()
    eccc_raw = eccc_extractor.extract()

    api_extractor = APIExtractor()
    api_raw = api_extractor.extract()

    print_header("VALIDATION")
    validator = DataValidator()
    eccc_valid, api_valid, _ = validator.validateData(eccc_raw, api_raw)

    print_header("TRANSFORMATION")
    cleaner = DataCleaner()
    eccc_clean = cleaner.clean(eccc_valid)
    api_clean = cleaner.clean(api_valid)

    aligner = DataAligner()
    eccc_aligned = aligner.align(eccc_clean)
    api_aligned = aligner.align(api_clean)

    normalizer = DataNormalizer()
    eccc_normalized = normalizer.normalize(eccc_aligned)
    api_normalized = normalizer.normalize(api_aligned)

    builder = UnifiedDataBuilder()
    unified_table = builder.build(eccc_normalized, api_normalized)

    import os
    base_dir = os.path.dirname(__file__)
    csv_path = os.path.join(base_dir, 'data', 'unified_data.csv')
    print(f"\n💾 Saving unified table to CSV: {csv_path}")
    unified_table.to_csv(csv_path, index=False)
    print(f"✓ Unified table saved to {csv_path}")

    print("\n⏹️  Done.")
    return True


if __name__ == '__main__':
    run_etl_pipeline()

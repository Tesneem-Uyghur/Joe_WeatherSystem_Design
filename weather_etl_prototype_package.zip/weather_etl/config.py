"""Configuration for minimal package"""

DATABASE_PATH = "weather_data.db"

API_URL = "https://api.open-meteo.com/v1/forecast"
API_PARAMS = {
    "latitude": 43.6532,
    "longitude": -79.3832,
    "hourly": "temperature_2m,precipitation",
    "daily": "temperature_2m_max,temperature_2m_min,precipitation_sum",
    "forecast_days": 16,
    "timezone": "UTC"
}

CSV_PATH = "data/eccc_data.csv"

TEMPERATURE_MIN = -50
TEMPERATURE_MAX = 50
INTERPOLATION_GAP_LIMIT = 3
